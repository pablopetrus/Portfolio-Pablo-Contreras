# SHERPA OS Starter

Antes de trabajar, lee y aplica [`AGENTS.md`](AGENTS.md) como reglas operativas y consulta [`DASHBOARD.md`](DASHBOARD.md) para localizar el proyecto pertinente. Al terminar trabajo significativo, actualiza la memoria siguiendo ese protocolo, si cuentas con permisos. No leas todos los proyectos por defecto ni repitas la documentación aquí.
