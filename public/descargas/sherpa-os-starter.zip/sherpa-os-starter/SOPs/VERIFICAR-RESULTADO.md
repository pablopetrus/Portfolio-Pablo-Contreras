# SOP — Verificar antes de marcar «terminado»

**Cuándo:** al cerrar una tarea con un artefacto, recomendación o acción que importe.

1. **Relee el objetivo:** ¿qué tenía que conseguir el usuario, más allá de redactar algo bonito?
2. **Comprueba el entregable:** ¿existe el archivo, resultado, cambio o borrador?
3. **Contrasta con la fuente:** ¿los datos sensibles, números, fechas y afirmaciones están respaldados?
4. **Prueba el funcionamiento:** si es código, ejecuta tests o una prueba representativa; si es texto, verifica instrucciones, enlaces y requisitos.
5. **Revisa límites y permisos:** ¿se pidió autorización antes de enviar, publicar, pagar, borrar o compartir información?
6. **Detecta fallo principal:** indica qué caso no pasó y cómo reproducirlo, sin esconderlo bajo un «todo correcto».
7. **Actualiza estado:** marca hecho, parcial, no comprobado o bloqueado, con evidencia.

**Salida mínima:** «Hecho: X. Verificado: Y. No comprobado: Z. Próximo paso: W».

No inventes pruebas. Un procedimiento que parece completo pero falla en el objetivo real **no está terminado**.
