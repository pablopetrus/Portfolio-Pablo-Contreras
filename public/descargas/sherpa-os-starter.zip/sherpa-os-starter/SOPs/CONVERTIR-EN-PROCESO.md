# SOP — Convertir un trabajo en un procedimiento reutilizable

**Activación:** una tarea ya se ha realizado y comprobado. Repetirla tiene valor real.

Antes de escribir un SOP, pregunta: **¿la haré de nuevo y qué parte puedo evitar repetir?** Si no lo sabes, no crees más documentación.

## Procedimiento
1. **Disparador:** cuándo debe usarse.
2. **Entradas:** datos y permisos imprescindibles; nunca secretos incrustados.
3. **Pasos mínimos:** qué hacer en orden y qué puede ejecutar un agente.
4. **Resultado verificable:** artefacto o métrica que confirma éxito.
5. **Casos negativos:** cuándo NO aplicarlo, error conocido y riesgo.
6. **Responsable:** quién verifica y aprueba acciones sensibles.
7. **Prueba:** repítelo con un segundo caso. Si funciona, conserva el SOP; si no, corrige el error.

Una **skill** puede empaquetar más adelante el SOP para una herramienta concreta. Una **automatización** solo tiene sentido cuando conoces su frecuencia, calidad y retorno; no es el primer paso.
