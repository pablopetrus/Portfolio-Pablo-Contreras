# DECISIONES — Taller de bicicletas (ejemplo ficticio)

| Decisión | Motivo | Estado |
| --- | --- | --- |
| Empezar con tres borradores manuales, no con un chatbot conectado | Permite evaluar utilidad sin permisos peligrosos | Vigente |
| No inventar precios, horarios ni plazos | La información no existe en el brief | Vigente |
| Medir ahorro de tiempo **solo después** de una prueba con usuarios reales | Evita declarar ROI hipotético como obtenido | Vigente |

**Regla:** registra aquí decisiones que cambien cómo trabajarás la próxima vez, no cada frase del chat.
