# ENTREGABLE — Respuestas tipo para taller (FICTICIO)

**No enviado.** Estos son borradores para revisión humana.

## 1. Solicitud de cita
«¡Gracias por escribirnos! Podemos ayudarte a revisar tu bicicleta. Para ofrecerte una cita, cuéntanos qué problema notas y qué días te vienen bien. Te confirmaremos la disponibilidad antes de reservar».

**Comprobar antes de usar:** canal de contacto, días de apertura y disponibilidad real.

## 2. Solicitud de presupuesto
«¡Claro! Para orientarte con un presupuesto necesitamos conocer el modelo de bicicleta, el problema y, si puedes, una foto. Con esa información te indicaremos los siguientes pasos. No podemos confirmar un precio hasta revisar el caso».

**Comprobar antes de usar:** política real de presupuestos y datos mínimos necesarios.

## 3. Estado de reparación
«¡Gracias por preguntar! Voy a comprobar en qué punto está la reparación. Te confirmaremos el estado en cuanto tengamos la información del taller. Preferimos no darte un plazo sin verificarlo».

**Comprobar antes de usar:** acceso autorizado al estado de reparación y procedimiento de consulta.

## Cierre de verificación
- Tres respuestas: **sí**.
- Precio/plazo inventado: **no**.
- Uso con clientes reales: **no probado**.
- Resultado verificable: **borradores escritos y revisables**, no ingresos ni ahorro medido.
