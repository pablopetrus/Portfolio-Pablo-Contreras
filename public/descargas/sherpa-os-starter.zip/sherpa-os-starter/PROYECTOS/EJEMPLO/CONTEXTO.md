# CONTEXTO — Taller de bicicletas (ejemplo ficticio)

**Importante:** negocio, cifras y personas inventados para aprender. No corresponden a un cliente real.

## Objetivo
Preparar tres respuestas reutilizables para consultas habituales de un taller de bicicletas ficticio. El objetivo es **reducir tiempo de redacción sin inventar información**. No enviar nada automáticamente.

## Restricciones
- No hay precios ni plazos confirmados por el propietario; deben quedar como campos pendientes.
- Las respuestas deben ser breves, amables y revisables por una persona.
- No recolectar ni tratar datos personales de clientes reales.
- El agente puede redactar y verificar contra este brief; no está autorizado a enviar correos.

## Criterios de éxito
1. Tres borradores utilizables: cita, presupuesto y estado de reparación.
2. Ningún precio, horario o plazo inventado.
3. Una persona puede señalar lo que falta validar antes de usar cada borrador.

## Fuente
Este brief ficticio. No supone que existan emails reales, métricas verificadas o una conexión de correo.
