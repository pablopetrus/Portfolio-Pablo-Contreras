# Roadmap: siete días para conseguir una capacidad útil

Esto no es un reto de productividad. Cada día termina con algo **observable**. Si tienes poco tiempo, haz solo los días 1 y 2 antes de ampliar nada.

| Día | Acción | Evidencia |
| --- | --- | --- |
| 1 | Elige un cuello de botella y define qué significa resolverlo | Una tarea y criterios de éxito en `ESTADO.md` |
| 2 | Usa al agente para producir un primer entregable | Archivo, borrador o proceso real, NO una promesa |
| 3 | Verifica y corrige el fallo más importante | Prueba o revisión documentada |
| 4 | Haz una segunda ejecución o pequeño experimento | Comparación con el primer intento |
| 5 | Registra únicamente las decisiones duraderas | `DECISIONES.md` actualizado |
| 6 | Si se repite y funciona, crea un SOP breve | SOP probado con otro caso |
| 7 | Mide: tiempo humano, errores, dinero o usuarios, según aplique | Datos reales o «todavía no medido» |

**Regla de oro:** si la segunda ejecución no mejora, no añadas agentes: mejora el proceso o el criterio de verificación.
