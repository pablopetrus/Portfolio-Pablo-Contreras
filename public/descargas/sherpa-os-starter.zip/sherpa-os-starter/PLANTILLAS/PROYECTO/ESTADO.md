# ESTADO — [NOMBRE DEL PROYECTO]

**Estado:** En preparación / En curso / Bloqueado / Verificado / Cerrado.

## Resultado buscado hoy
[Una tarea con entregable concreto.]

## Qué se hizo de verdad
[Archivo, borrador, cambio o acción ejecutada. No inventar.]

## Evidencia y pruebas
[Qué comprobaste; enlace o ruta de archivo.]

## Lo pendiente / no comprobado
[Incertidumbres, permisos y bloqueos reales.]

## Próxima acción única
[Verbo + objeto + criterio de terminado.]
