# DECISIONES — [NOMBRE DEL PROYECTO]

| Fecha | Decisión vigente | Motivo | Sustituye a |
| --- | --- | --- | --- |
| [AAAA-MM-DD] | [Qué harás / no harás] | [Evidencia o criterio] | [Ninguna o decisión anterior] |

Guarda decisiones duraderas, no toda la conversación. Si cambias de criterio, marca el anterior como sustituido.
