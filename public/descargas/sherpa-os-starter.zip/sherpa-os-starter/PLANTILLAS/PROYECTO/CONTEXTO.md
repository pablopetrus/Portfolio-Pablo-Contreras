# CONTEXTO — [NOMBRE DEL PROYECTO]

## Para qué existe
[Problema, usuario y resultado deseado.]

## Restricciones
[Presupuesto, tiempo, privacidad, herramientas permitidas, acciones que requieren aprobación.]

## Criterios de éxito
1. [Resultado observable 1.]
2. [Resultado observable 2.]

## Fuentes fiables
[Archivos, enlaces o personas que autorizan datos.]
