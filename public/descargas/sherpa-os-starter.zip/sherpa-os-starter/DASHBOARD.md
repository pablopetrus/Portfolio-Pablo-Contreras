# Dashboard

> **Un punto de entrada, no una lista interminable.** Actualízalo cuando cambie algo importante; el detalle vive dentro de cada proyecto.

## Ahora

**Proyecto de ejemplo (ficticio):** [Respuestas para un taller de bicicletas](PROYECTOS/EJEMPLO/ESTADO.md)  
**Estado:** Primera versión preparada; pendiente de comprobarla con el responsable.  
**Resultado observable:** Tres respuestas tipo redactadas y verificadas contra el brief ficticio.  
**Siguiente acción:** Validar precios y plazos con quien gestiona el negocio antes de utilizar los borradores.  
**Evidencia:** [Borradores preparados](PROYECTOS/EJEMPLO/ENTREGABLE.md). **No se han enviado mensajes.**

## Mis proyectos

| Proyecto | Resultado buscado | Estado | Próxima acción |
| --- | --- | --- | --- |
| [EJEMPLO](PROYECTOS/EJEMPLO/ESTADO.md) | Reducir trabajo repetitivo de respuesta con borradores fiables | Borrador validado contra brief; no probado con negocio real | Revisar con responsable ficticio |

Cuando crees tu primer proyecto, puedes **eliminar la fila ficticia** o conservarla como referencia archivada. No conviertas ideas de futuro en proyectos activos.

## Acceso rápido

- [Reglas de los agentes](AGENTS.md)
- [Plantilla de un proyecto](PLANTILLAS/PROYECTO/CONTEXTO.md)
- [Cómo verificar](SOPs/VERIFICAR-RESULTADO.md)
- [Cuándo crear un procedimiento](SOPs/CONVERTIR-EN-PROCESO.md)

## Regla de foco

Si la próxima acción es «organizar el dashboard», pregunta primero: **¿qué resultado concreto está bloqueado?** Si no hay respuesta, vuelve al trabajo.
