# Sistema de trabajo con agentes de IA — SHERPA OS Starter

**De una tarea importante a un resultado verificable. Y de un resultado a un proceso reutilizable.**

Este kit gratuito es una **carpeta de trabajo real** para Codex, Claude Code y otros entornos agénticos con acceso a archivos. No es un curso de prompts ni una copia del SHERPA privado del autor. No necesitas pagar por una plataforma, configurar conectores ni instalar una aplicación nueva para empezar. Sí necesitas acceso a un agente capaz de leer y editar archivos locales si quieres que mantenga la memoria por ti.

> **Idea central:** elegir bien → ejecutar pronto → verificar → guardar contexto → repetir lo que funciona.

## Empieza en cinco minutos

1. **Descarga y descomprime** la carpeta. Abre **esta carpeta completa** como proyecto en Codex, Claude Code o tu entorno favorito.
2. **Lee `DASHBOARD.md`**. Es el mapa: muestra dónde estás, qué importa y cuál es el siguiente paso.
3. **Pega este mensaje** en el agente:

   > Lee `AGENTS.md` y `DASHBOARD.md`. Quiero empezar un proyecto real. Ayúdame a escoger UNA tarea que pueda producir un resultado útil esta semana. Pregúntame solo lo indispensable. Crea el proyecto desde `PLANTILLAS/PROYECTO/`, haz conmigo la primera ejecución y verifica el resultado antes de darlo por terminado. Al acabar, actualiza los archivos pertinentes. No crees complejidad innecesaria.

4. **Haz el primer trabajo.** Una propuesta enviada *con tu aprobación*, una tabla comprobada, una landing operativa, un pequeño script o un proceso manual más rápido. No empieces montando automatizaciones.
5. **Vuelve mañana y di:** «Retomemos. Lee el dashboard y el estado del proyecto; dime cuál es el siguiente paso verificable».

**¿Tu herramienta no carga automáticamente las instrucciones?** Pídele explícitamente que lea `AGENTS.md` y `DASHBOARD.md`. `CLAUDE.md` facilita el arranque en Claude Code; otros entornos pueden tratar estos archivos de modo diferente. Las actualizaciones no ocurren por arte de magia: el agente necesita acceso de escritura y debe ejecutar el protocolo.

## Qué contiene cada archivo

| Archivo | Para qué sirve |
| --- | --- |
| [`AGENTS.md`](AGENTS.md) | Reglas del agente: foco, verificación, memoria y seguridad. |
| [`CLAUDE.md`](CLAUDE.md) | Punto de entrada corto para Claude Code. |
| [`DASHBOARD.md`](DASHBOARD.md) | Mapa central de proyectos activos, resultados y próximas acciones. |
| [`PROYECTOS/EJEMPLO/`](PROYECTOS/EJEMPLO/) | Un caso ficticio completo, con entregable, estado y decisiones. |
| [`PLANTILLAS/PROYECTO/`](PLANTILLAS/PROYECTO/) | Tres archivos que puedes copiar para empezar tu propio proyecto. |
| [`SOPs/`](SOPs/) | Cómo verificar y cuándo convertir un trabajo en proceso reutilizable. |
| [`GUIA_ROADMAP_SHERPA_OS.pdf`](GUIA_ROADMAP_SHERPA_OS.pdf) | Guía visual paso a paso para quien prefiera leer antes de abrir el agente. |

## Cómo crear un proyecto real

Copia `PLANTILLAS/PROYECTO` a `PROYECTOS/NOMBRE-CORTO/` (o pídeselo al agente). Rellena únicamente:

- **`CONTEXTO.md`**: para quién, objetivo, restricciones y fuentes fiables.
- **`ESTADO.md`**: resultado buscado, trabajo realizado, evidencia, bloqueo y siguiente paso.
- **`DECISIONES.md`**: decisiones duraderas y por qué se tomaron.

Añade una línea en `DASHBOARD.md`. **No necesitas más documentos hasta que exista un problema real que no puedas resolver con esos tres.**

## Qué no hace el kit

- No se conecta automáticamente a Google Drive, Gmail, Calendar, WhatsApp ni otras cuentas.
- No termina tareas en segundo plano ni garantiza memoria perfecta: la continuidad sale de los archivos que realmente queden actualizados.
- No garantiza clientes, dinero ni ahorro de tiempo. **Primero mide un resultado real.**
- No envía correos, paga, publica, borra archivos sensibles ni otorga permisos sin tu autorización.
- No convierte ideas de una lista en obligaciones: un proyecto solo está activo si tú lo decides.

## La prueba de valor

Tras una semana, pregúntate: **¿Qué resultado que no existía antes he conseguido? ¿Qué he comprobado? ¿Qué tarea podré realizar mejor o más rápido la próxima vez?** Si las respuestas son «ninguno», reduce el sistema; no añadas más archivos.

## Licencia y privacidad

MIT. Gratis para usar, adaptar y compartir. Contiene ejemplos **100 % ficticios**. Nunca subas credenciales, información de clientes o documentos privados a un repositorio público. Guarda tus proyectos reales en un repositorio privado o carpeta local, si contienen datos sensibles.

Creado por **Pablo Contreras (Petrus)** · [pablopetrus.com](https://pablopetrus.com) · 2026.
